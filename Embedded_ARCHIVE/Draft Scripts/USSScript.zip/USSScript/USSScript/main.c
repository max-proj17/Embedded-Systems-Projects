/*
 * USSScript.c
 *
 * Created: 4/29/2023 8:15:27 PM
 * Author : maxfi
 */ 

#include <avr/io.h>
#include <stdlib.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include <stdio.h>

#define F_CPU 16000000
#define FOSC 16000000 // Clock Speed
#define BAUD 9600
#define MYUBRR FOSC/16/BAUD-1
#define TRIG_PIN PD2   // Trigger pin (digital output)
#define ECHO_PIN PD3   // Echo pin (digital input)
#define MAX_DISTANCE 3050 // Maximum distance in centimeters (30.5 cm = 3050)

volatile uint8_t timerOverflow = 0;
volatile uint32_t pulseDuration = 0;


void USART_Init( unsigned int ubrr)
{
	///*Set baud rate */
	UBRR0H = (unsigned char)(ubrr>>8);
	UBRR0L = (unsigned char)ubrr;
	/*Enable receiver and transmitter */
	UCSR0B = (1<<RXEN0)|(1<<TXEN0);
	/* Set frame format: 8data, 2stop bit */
	UCSR0C = (1<<USBS0)|(3<<UCSZ00);
}
void USART_Transmit( unsigned char data )
{
	/* Wait for empty transmit buffer */
	while ( !( UCSR0A & (1<<UDRE0)) );
	/* Put data into buffer, sends the data */
	UDR0 = data;
}
unsigned char USART_Receive( void )
{
	/* Wait for data to be received */
	while ( !(UCSR0A & (1<<RXC0)) );
	/* Get and return received data from buffer */
	//Dtostrf
	return UDR0;
}

ISR(TIMER1_OVF_vect) {
	timerOverflow++;
	/*
	USART_Transmit('t');
	USART_Transmit(':');
	USART_Transmit(timerOverflow);
	USART_Transmit(' ');
	USART_Transmit(0x0A);
	*/
}

void init_HC_SR04() {
	DDRD |= (1 << TRIG_PIN);   // Set trigger pin as output
	DDRD &= ~(1 << ECHO_PIN);  // Set echo pin as input
	TCCR1B |= (1 << CS10);     // Enable timer with prescaler = 1
	TIMSK1 |= (1 << TOIE1);    // Enable timer overflow interrupt
}

uint32_t pulseIn() {
	pulseDuration = 0;
	timerOverflow = 0;
	PORTD &= ~(1 << TRIG_PIN);  // Set trigger pin low
	_delay_us(2);
	PORTD |= (1 << TRIG_PIN);   // Set trigger pin high for 10 us
	_delay_us(10);
	PORTD &= ~(1 << TRIG_PIN);  // Set trigger pin low
	while (!(PIND & (1 << ECHO_PIN))) {
		 if(timerOverflow > 1) // Timeout after 100ms
		 {
			 return 0;
		 }
	}  // Wait for echo pin to go high
	TCNT1 = 0;                  // Reset timer count
	TIFR1 |= (1 << TOV1);       // Clear timer overflow flag
	TIMSK1 |= (1 << TOIE1);     // Enable timer overflow interrupt
	sei();                      // Enable global interrupts
	while ((PIND & (1 << ECHO_PIN))) {  // Wait for echo pin to go low
		if (timerOverflow > 1) {    // If no echo, exit loop after timeout
			TIMSK1 &= ~(1 << TOIE1);  // Disable timer overflow interrupt
			cli();    // Disable global interrupts
			return 0;
		}
	}
	TIMSK1 &= ~(1 << TOIE1);    // Disable timer overflow interrupt
	cli();    // Disable global interrupts
	pulseDuration = timerOverflow * 65536UL + TCNT1;
	return pulseDuration;
}

int main(void)
{
	//ADC_Init();
	USART_Init(MYUBRR);
	init_HC_SR04();
	
	while (1) {
		uint32_t pulseDuration = pulseIn();
		uint32_t distance = pulseDuration/58/13; //70.6; // Calculate distance in centimeters
		//distance = (distance / 3050.0f) * 12.0f;
		/*
		if(distance > MAX_DISTANCE)
		{
			distance = 0;
		}
		*/
		char str[11];  // Maximum digits in a 32-bit unsigned integer is 10 (plus null terminator)
		//sprintf(str, "%lu", distance);  // Convert integer to string
		dtostrf(distance,4,2,str);
		for (int i = 0; i < strlen(str); i++) {  // Transmit string character by character
			USART_Transmit(str[i]);
		}
		USART_Transmit(' ');
		USART_Transmit(0x0A);
		_delay_ms(500);   // Delay between measurements
	}
	return 0;
}

